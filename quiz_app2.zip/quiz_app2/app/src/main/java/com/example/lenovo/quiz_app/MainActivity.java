package com.example.lenovo.quiz_app;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.example.lenovo.quiz_app.R;

public class MainActivity extends AppCompatActivity {

    RadioGroup rg;
    int score = 0;
    CheckBox  cb3, cb4,cb5;
    EditText et;
    int p1=0,p2=0,p3=0,p4=0,p5=0,p6=0,p7=0,p8=0;
    String s = "Your Response has been submitted";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rg = (RadioGroup) findViewById(R.id.rgroup1);
        cb3 = (CheckBox) findViewById(R.id.chkcb27);
        cb4 = (CheckBox) findViewById(R.id.chkcb28);
        cb5 = (CheckBox) findViewById(R.id.chkcb29);
    }
    public void checkbox(View v1)
    {
       if(cb3.isChecked()&&cb4.isChecked()&&!cb5.isChecked())
       {
           score++;
       }
       else
           score=score+0;
    }
    public void rbclick(View v) {
        boolean checked = ((RadioButton) v).isChecked();
        switch (v.getId()) {
            case R.id.radioButton3:
                if(p2==0){
                    if (checked) {
                        score = score + 1;
                        p2++;
                    }
                }
                break;
            case R.id.radioButton5:
                if(p3==0){
                    if (checked) {
                        score = score + 1;
                        p3++;
                    }
                }
                break;
            case R.id.radioButton10:
                if(p4==0){
                    if (checked) {
                        score = score + 1;
                        p4++;
                    }
                }
                break;
            case R.id.radioButton14:
                if(p5==0){
                    if (checked) {
                        score = score + 1;
                        p5++;
                    }
                }
                break;
            case R.id.radioButton18:
                if(p6==0){
                    if (checked) {
                        score = score + 1;
                        p6++;
                    }
                }
                break;
            case R.id.radioButton21:
                if(p7==0){
                    if (checked) {
                        score = score + 1;
                        p7++;
                    }
                }
                break;
            case R.id.radioButton29:
                if(p8==0){
                    if (checked) {
                        score = score + 1;
                        p8++;
                    }
                }
                break;
            case R.id.radioButton34:
                if(p1==0)
                {
                    if(checked){
                        score = score +1;
                        p1++;
                        }
                }
                break;
        }
    }
   private void textCompare(View v2)
    {
        et = (EditText) findViewById(R.id.edit);
        if(et.getText().toString().equals("26"))
        {
            score=score+1;
        }
    }
    public void submitans(View v)
    {
        textCompare(et);
        String finalscore = "you have Scored " + score+"  out of 10";
        Toast.makeText(getApplicationContext(),finalscore,Toast.LENGTH_LONG).show();
    }
    public void again(View v)
    {
        Intent i=new Intent(this,MainActivity.class);
        startActivity(i);
    }
}
